# shoe-store
ecommerce website in html and css and a litttle js with the help of Bedimcode
